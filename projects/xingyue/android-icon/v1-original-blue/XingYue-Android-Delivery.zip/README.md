# ChatGPT Deliverables | 交付文件仓库

此仓库用于长期归档 ChatGPT 为我创建的设计素材、代码、报告、文档及其他交付文件。按项目/类别/版本保存，不替代业务项目源代码仓库。

## 交付目录

- [`projects/xingyue/android-icon/v1-original-blue/`](projects/xingyue/android-icon/v1-original-blue/)：星阅阅读 App 原版蓝色 Logo、SVG 矢量复刻和 Android 启动图标资源。
  - [直接下载完整素材 ZIP](projects/xingyue/android-icon/v1-original-blue/XingYue-Android-Delivery.zip)（在 GitHub 文件页选择 Download raw file）。

## 索引

- [`DELIVERIES.json`](DELIVERIES.json)：交付清单（便于未来增量归档与自动化）。
- [`SHA256SUMS.txt`](SHA256SUMS.txt)：文件 SHA-256 校验和。

## 约定

1. 每次交付使用明确的项目目录与版本目录，避免覆盖已认可版本。
2. 文件保留可编辑源文件（如 SVG）和可直接使用的产物（如 PNG、PDF、ZIP）。
3. 每个项目附 `README.md` 说明用途、安装方式和原始设计与复刻之间的差异。
4. 默认先使用 private（私有）仓库；避免上传凭据、客户数据和公司保密资料。
5. 交付完成后提供实际 GitHub 文件路径或已验证的 Releases 下载地址，不再仅使用 ChatGPT 沙箱链接。

> 注意：本仓库当前为 Public（公开）。不要在这里上传内部项目代码、个人敏感资料或机密文件。

## 使用说明

连接的 GitHub 工具可能需要手动授予新仓库访问权限。生成/上传成功后，请以仓库文件列表为准。
