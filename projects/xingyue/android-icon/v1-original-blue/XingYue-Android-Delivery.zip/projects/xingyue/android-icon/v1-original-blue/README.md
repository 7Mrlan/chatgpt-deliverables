# 星阅 Android App Logo · v1 原版蓝色

这是已认可的**原版蓝色**视觉方向。

- `01_approved_original/XingYue_approved_original_1024.png`：最接近已确认原图的高清 PNG。
- `01_approved_original/XingYue_GooglePlay_512.png`：512px PNG。
- `02_editable_svg/XingYue_vector_recreation.svg`：根据原图重绘的可编辑 SVG，**并非与原图逐像素相同**。
- `03_android_adaptive/android-res/`：Android launcher 的 mipmap、drawable 和 adaptive icon 配置。
- `04_previews/XingYue_android_comparison.png`：原图与复刻对照。
- `README_安装说明.txt`：安装步骤。

### 安装

将 `03_android_adaptive/android-res/` 目录下的资源文件合并到 Android 项目的 `app/src/main/res/` 中。安装前备份原 `ic_launcher` 图标资源。在 AndroidManifest.xml 的 application 上使用 `@mipmap/ic_launcher` 与 `@mipmap/ic_launcher_round`。验证不同启动器裁切和深浅色模式下的呈现。

### 版本说明

此目录为用户确认的原版蓝色，不自行调整颜色或图形轮廓。后续改版另建 v2 目录。
