星阅（Xing Yue）Android 图标资源 — 原版蓝色

本次使用用户 2026-10-22 确认的原版截图，未进行任何换色。

【最还原原版】
01_approved_original/XingYue_approved_original_1024.png：直接从你认可的截图裁取并高清放大，视觉最接近原图。请注意其原始有效像素约 452×452；1024px 是放大导出，不是增加原生细节。
01_approved_original/XingYue_original_symbol_transparent.png：从原截图分离的透明蓝色图形。
01_approved_original/XingYue_GooglePlay_512.png：纯白背景商店图标。

【真正可编辑的 SVG】
02_editable_svg/XingYue_vector_recreation.svg：重新手绘的矢量复刻稿，轮廓与视觉尽量接近，但不是原作者的原始 SVG，和截图并非逐像素相同。
02_editable_svg/XingYue_vector_symbol_transparent.svg：不带背景的图形。
02_editable_svg/XingYue_android_adaptive_foreground.svg：按 Android 自适应图标安全区排版的矢量版。

【直接安装到 Android 工程】
03_android_adaptive/android-res 下含 mipmap-mdpi...xxxhdpi/、mipmap-anydpi-v26/、drawable/。
请把此文件夹里的各目录合并复制到 Android app/src/main/res/（不要覆盖项目中的整个 res 目录）。
然后确认 AndroidManifest.xml 中 <application> 有
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round"

其中 adaptive foreground 是直接由你认可的截图抠图而成，以最大限度保留原图渐变与形态；位于 108dp 画布中的中央安全区。
如果项目中已有 ic_launcher.* 文件，请先备份原图标；资源目录仅含 Logo 相关资源。

【说明】
Android 的 launcher 主图标不能直接使用网页 SVG 作为资源；请使用 ZIP 的 mipmap 资源或经 Android Studio Image Asset 导入 PNG。
PNG 保留原图外观；SVG 是高质量近似重绘。该图标在公开发布前，请自行做商标/图形相似性检索。
