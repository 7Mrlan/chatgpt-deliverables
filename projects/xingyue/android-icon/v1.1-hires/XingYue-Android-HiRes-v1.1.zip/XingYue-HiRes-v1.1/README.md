# 星阅 Android Logo · v1.1 高清矢量复刻版

**原版蓝色设计不变。** 修正 v1 从 452×452 的展示截图裁切并放大到 1024 的问题。

## 主推荐文件

- 01_vector-master/XingYue_Master_Vector.svg — 可无损缩放的 SVG 复刻稿，适合继续修改。
- 02_high-resolution/XingYue_Icon_2048.png — 从 SVG 全新渲染的真实 2048 像素文件。
- 02_high-resolution/XingYue_Icon_1024.png — SVG 渲染的真实 1024 像素文件。
- 02_high-resolution/XingYue_Transparent_2048.png — 透明底纸页图案。
- 03_android/res/ — Android 各 mipmap 密度图标以及自适应图标 XML 和前景 PNG。
- 04_quality-preview/ — 旧截图有效像素与新 SVG 的对比。

**注意：本版本是矢量复刻，而不是之前 AI 展示图中 Logo 的原生矢量设计文件；因此曲线和内部渐变可能与展示截图有少量差异。** 相比原截图裁切放大，边缘更清晰，尺寸可重复生成。依然留存 v1 原版截图参考，不覆盖用户确认的品牌设计。

## Android 集成

1. 备份工程现有 ic_launcher 资源。
2. 把 `03_android/res/` 下的资源子目录合并进入 `app/src/main/res/`。
3. 确保 `AndroidManifest.xml` 的 `application` 含 `android:icon="@mipmap/ic_launcher"` 和 `android:roundIcon="@mipmap/ic_launcher_round"`。
4. 自适应图标由透明前景与底色组成。legacy 图标已导出 48–192 px。
5. 若采用自定义主题色请保留无修改的 v1.1 Master SVG 作为回退。
